const transactionForm = document.getElementById('transactionForm');
const transactionsList = document.getElementById('transactionsList');

transactionForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(transactionForm);
  const transactionData = Object.fromEntries(formData.entries());

  try {
    const response = await axios.post('/api/transactions', transactionData);
    const { message, transaction } = response.data;

    alert(message);

    transactionForm.reset();

      fetchTransactions();
  } catch (error) {
    console.error('Error adding transaction:', error);
    alert('Failed to add transaction. Please try again.');
  }
});

async function fetchTransactions() {
  try {
    const response = await axios.get('/api/transactions');
    const transactions = response.data;

    transactionsList.innerHTML = ''; 

    transactions.forEach((transaction) => {
      const transactionItem = document.createElement('div');
      transactionItem.classList.add('transaction-item');
      transactionItem.innerHTML = `
        <strong>${transaction.type.toUpperCase()}</strong> - 
        ${transaction.description} - 
        Amount: ${transaction.amount.toFixed(2)}
      `;
      transactionsList.appendChild(transactionItem);
    });
  } catch (error) {
    console.error('Error fetching transactions:', error);
  }
}

fetchTransactions();
